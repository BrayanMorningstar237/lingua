@echo off
call "%~dp0server\start-voice.cmd"
