' Langwa natural voice: double-click. No window; progress shows in Langwa.
Dim fs: Set fs = CreateObject("Scripting.FileSystemObject")
CreateObject("WScript.Shell").Run "wscript.exe """ & fs.GetParentFolderName(WScript.ScriptFullName) & "\server\start-voice.vbs""", 1, False
