Langwa natural voice

Windows: double-click "Start Langwa voice.cmd".
Mac / Linux: open a terminal in this folder and run:  sh server/start-voice.sh

The first time, it downloads about 700 MB once (it resumes if the connection drops) and asks
whether to start with the computer. Keep its window open; Langwa then reads with this voice.
Everything stays in this folder and runs on this computer, offline. To remove it, delete the folder.

Voix naturelle Langwa

Windows : double-cliquez sur "Start Langwa voice.cmd".
Mac / Linux : ouvrez un terminal dans ce dossier et lancez :  sh server/start-voice.sh

La premiere fois, environ 700 Mo sont telecharges une seule fois (reprise si la connexion coupe).
Gardez la fenetre ouverte ; Langwa lit alors avec cette voix. Tout reste dans ce dossier, hors ligne.

Model and voices: Africa TTS, CC-BY-NC-4.0 (AfriSpeech). Code: MIT.
