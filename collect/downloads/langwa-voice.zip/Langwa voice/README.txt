Langwa natural voice

Windows: double-click "Start Langwa voice". A progress page opens in your browser (also shown in Langwa
(click the Langwa button in the browser). It shows "Natural voice ready" when it can read aloud.
Mac / Linux: open a terminal in this folder and run:  sh server/start-voice.sh

The first time, it downloads about 700 MB once (it resumes if the connection drops) and asks
whether to start with the computer. It sleeps when unused. If something fails, a message says so;
details are in server\models\voice.log. Fallback: double-click server\start-voice.cmd.
Everything stays in this folder and runs on this computer, offline. To remove it, delete the folder
(and "Langwa voice" in Win+R, shell:startup, if you chose to start it with the computer).

Voix naturelle Langwa

Windows : double-cliquez sur "Start Langwa voice". Une page de progression s ouvre dans le navigateur (aussi dans Langwa
(bouton Langwa du navigateur). Il affiche "Voix naturelle prete" quand elle peut lire.
Mac / Linux : ouvrez un terminal dans ce dossier et lancez :  sh server/start-voice.sh

La premiere fois, environ 700 Mo sont telecharges une seule fois (reprise si la connexion coupe).
En cas de probleme, un message le dit ; details dans server\models\voice.log. Tout reste ici, hors ligne.

Model and voices: Africa TTS, CC-BY-NC-4.0 (AfriSpeech). Code: MIT.
